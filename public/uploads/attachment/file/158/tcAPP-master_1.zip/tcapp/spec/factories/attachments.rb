FactoryGirl.define do
  factory :attachment do
    file "MyString"
  end
end
